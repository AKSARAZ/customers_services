<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright © Dwitian Tangguh Edinugraha 2025</span>
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\Laravel\customers_services\resources\views/layouts/footer.blade.php ENDPATH**/ ?>